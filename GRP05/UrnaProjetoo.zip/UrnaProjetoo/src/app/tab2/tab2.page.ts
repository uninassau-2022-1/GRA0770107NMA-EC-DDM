import { Component } from '@angular/core';  
@Component({ 
  selector: 'app-tab2', 
  templateUrl: 'tab2.page.html', 
  styleUrls: ['tab2.page.scss'] 
}) 
export class Tab2Page { 
  public votos: any;
  public totalVotos: any;
 
  constructor() {
    this.votos = [{
      "numero": [10, 20, 30, 40, 50, 60, 70],
      "votos":  [ 0,  0,  0,  0,  0,  0,  0],
      "perc":   [ 0,  0,  0,  0,  0,  0,  0],
      "total": 0
    }];
  } 

  computar (voto: string) { 
    console.log("voto" + voto);
    console.log("vetor" + JSON.stringify(this.votos[0]['votos'][0]));

    switch (voto) {
      case '10':
        this.votos[0]['votos'][0] = this.votos[0]['votos'][0] + 1;
        this.votos[0]['total'] = this.votos[0]['total'] + 1;
        this.calcPerc();
        console.log("votou no 10");
        break;
      case '20':
        this.votos[0]['votos'][1] = this.votos[0]['votos'][1] + 1;
        this.votos[0]['total'] = this.votos[0]['total'] + 1;
        this.calcPerc();
        console.log("votou no 20");
        break;
      default:
        console.log("foi no padrao");
        break;
        case '30':
        this.votos[0]['votos'][2] = this.votos[0]['votos'][2] + 1;
        this.votos[0]['total'] = this.votos[0]['total'] + 1;
        this.calcPerc();
        console.log("votou no 30");
        break;
        case '40':
        this.votos[0]['votos'][3] = this.votos[0]['votos'][3] + 1;
        this.votos[0]['total'] = this.votos[0]['total'] + 1;
        this.calcPerc();
        console.log("votou no 40");
        break;
        case '50':
        this.votos[0]['votos'][4] = this.votos[0]['votos'][4] + 1;
        this.votos[0]['total'] = this.votos[0]['total'] + 1;
        this.calcPerc();
        console.log("votou no 50");
        break;
    }
    console.log("Aqui" + JSON.stringify(this.votos));

  } 

  calcPerc(){
    this.votos[0]['perc'][0] = ((this.votos[0]['votos'][0] / this.votos[0]['total']) * 100).toPrecision(3);
    this.votos[0]['perc'][1] = ((this.votos[0]['votos'][1] / this.votos[0]['total']) * 100).toPrecision(3);
    this.votos[0]['perc'][2] = ((this.votos[0]['votos'][2] / this.votos[0]['total']) * 100).toPrecision(3);
    this.votos[0]['perc'][3] = ((this.votos[0]['votos'][3] / this.votos[0]['total']) * 100).toPrecision(3);
    this.votos[0]['perc'][4] = ((this.votos[0]['votos'][4] / this.votos[0]['total']) * 100).toPrecision(3);
  }
 
}
